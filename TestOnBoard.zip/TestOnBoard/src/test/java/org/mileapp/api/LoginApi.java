package org.mileapp.api;

import static io.restassured.RestAssured.given;

import org.junit.Assert;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class LoginApi {
	
	@Before
	public void setup() {
		RestAssured.baseURI = "https://apidev.mile.app/v1";
	}
	
	@After
	public void login() {
		RestAssured.useRelaxedHTTPSValidation();
		
		String requestBody = "{ \r\n"
				+ "\r\n"
				+ "  \"organizationName\":\"testonboard\",\r\n"
				+ "  \"username\":\"validUsername\",\r\n"
				+ "  \"password\":\"validPasswod\"\r\n"
				+ "}";
		
		Response response = given().header("Content-Type","application/json")
				.and()
				.body(requestBody)
				.when()
				.post("/org_login")
				.then()
				.extract()
				.response();
		
		Assert.assertEquals(200, response.getStatusCode());
	}
}
