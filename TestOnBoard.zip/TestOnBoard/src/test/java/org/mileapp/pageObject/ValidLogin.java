package org.mileapp.pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ValidLogin {
	WebDriver driver;
	WebDriverWait wait;
	public ValidLogin(WebDriver driver) {
		this.driver = driver;
	}
	
	public void inputOrganizationName(String organizationName) {
		By input_organizationName	= By.xpath("//input[@name='organization']");
		driver.findElement(input_organizationName).sendKeys(organizationName);
		driver.findElement(input_organizationName).sendKeys(Keys.ENTER);
	}
	
	public void inputUsername(String username) throws InterruptedException {
		Thread.sleep(5000);
		By input_username	= By.xpath("//input[@name='email or username']");
		driver.findElement(input_username).sendKeys(username);
	}
	
	
	public void inputPassword(String password) {
		By input_password	= By.xpath("//input[@name='password']");
		driver.findElement(input_password).sendKeys(password);
	}
	
	public void clickLogin() {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		By button_login	= By.xpath("//span[text()='Login']/parent::button");
		try {
			driver.findElement(button_login).click();
		} catch (ElementClickInterceptedException e) {
			js.executeScript("arguments[0].click()", driver.findElement(button_login));
		}
	}
}
