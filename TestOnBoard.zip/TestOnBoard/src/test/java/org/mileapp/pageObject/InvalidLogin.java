package org.mileapp.pageObject;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class InvalidLogin {
	WebDriver driver;
	WebDriverWait wait;
	
	public InvalidLogin(WebDriver driver) {
		this.driver = driver;
	}
	
	public void inputOrganizationName(String organizationName) {
		By input_organizationName	= By.xpath("//input[@name='organization']");
		driver.findElement(input_organizationName).sendKeys(organizationName);
		driver.findElement(input_organizationName).sendKeys(Keys.ENTER);
		if(organizationName.equals("")) {
			By span_validateField	= By.xpath("//span[@class='validate-failed' and text()='The organization field is required']");
			Assert.assertEquals(true, driver.findElements(span_validateField).size() != 0);
		}else if(!(organizationName.equals("testonboard"))) {
			By span_validateField	= By.xpath("//span[@class='validate-failed' and text()='oops :( "+organizationName+".mile.app is not available']");
			Assert.assertEquals(true, driver.findElements(span_validateField).size() != 0);
		}
	}
	
	public void verifyInputUsername() throws InterruptedException {
		Thread.sleep(5000);
		By input_username	= By.xpath("//input[@name='email or username']");
		Assert.assertEquals("true", driver.findElement(input_username).getAttribute("disabled"));
	}
	
	public void verifyInputPassword() {
		By input_password	= By.xpath("//input[@name='password']");
		Assert.assertEquals("true", driver.findElement(input_password).getAttribute("disabled"));
		
	}
	
	public void verifyLoginButton() {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		By button_login	= By.xpath("//span[text()='Login']/parent::button");
		Assert.assertEquals("true", driver.findElement(button_login).getAttribute("disabled"));
	}
}
