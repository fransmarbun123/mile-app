package org.mileapp.stepDefinition;

import java.util.concurrent.TimeUnit;

import org.mileapp.pageObject.InvalidLogin;
import org.mileapp.pageObject.ValidLogin;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Glue {
	WebDriver driver;
	ValidLogin validLogin;
	InvalidLogin invalidLogin;
	
	@SuppressWarnings("deprecation")
	@Given("User is on login site")
	public void user_is_on_login_site() {
		System.setProperty("webdriver.chrome.driver","src\\test\\driver\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		options.setAcceptInsecureCerts(true);
		DesiredCapabilities handleSSLeer = DesiredCapabilities.chrome();
		handleSSLeer.setCapability (CapabilityType.ACCEPT_SSL_CERTS, true);
		driver = new ChromeDriver(handleSSLeer);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://taskdev.mile.app/login");
	}

	@When("User input login form")
	public void user_input_login_form() throws InterruptedException {
	    /*
		validLogin = new ValidLogin(driver);
	    validLogin.inputOrganizationName("testonboard");
	    validLogin.inputUsername("validUsername");
	    validLogin.inputPassword("validPassword");
	    validLogin.clickLogin();
	    */
		
		invalidLogin = new InvalidLogin(driver);
		invalidLogin.inputOrganizationName("");
		invalidLogin.verifyInputUsername();
		invalidLogin.verifyInputPassword();
	}

	@Then("User successfully logged in")
	public void user_successfully_logged_in() {
	    System.out.println("Done");
	    //driver.close();
	}
}
