<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>mile app logo</description>
   <name>img_logo</name>
   <tag></tag>
   <elementGuidId>702ee2dc-d882-46bb-8b4c-5b58a8f540a9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//img[@class='logo-img']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
