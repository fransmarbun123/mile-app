<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>password locator</description>
   <name>input_password</name>
   <tag></tag>
   <elementGuidId>8a6f6403-0479-4bec-b10d-39071158951c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name='password']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
