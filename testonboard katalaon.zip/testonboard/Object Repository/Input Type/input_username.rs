<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>username locator</description>
   <name>input_username</name>
   <tag></tag>
   <elementGuidId>bf44718e-acc2-4d08-951c-767ad7b956cd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name='email or username']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
