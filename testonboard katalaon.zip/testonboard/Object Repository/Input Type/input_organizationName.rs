<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>organization name locator</description>
   <name>input_organizationName</name>
   <tag></tag>
   <elementGuidId>24a3dd37-6953-44cb-9c36-8722d5179f3b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name='organization']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
