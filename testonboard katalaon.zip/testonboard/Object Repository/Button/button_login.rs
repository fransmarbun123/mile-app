<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>login button locator</description>
   <name>button_login</name>
   <tag></tag>
   <elementGuidId>818926c4-5a5f-4b3f-a875-4a926b565db9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='Login']/parent::button</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
